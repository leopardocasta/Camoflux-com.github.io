# Camoflux: Levels & Bosses

Camoflux is a hand-painted, ecological stealth-exploration game built in Unreal Engine 5. Camouflage into painted patterns, modulate turbulence and light, and move energy through the land to reshape a cyclical cataclysm.

Developer: Levels & Bosses (Leo Castañeda)
Publisher: Otro Inventario
Genre: Ecological stealth-exploration game
Status: In development
Release: Coming soon
Platform: PC (Steam)
Engine: Unreal Engine 5
Steam: https://store.steampowered.com/app/897980/Camoflux_Levels__Bosses/
Trailer: https://www.youtube.com/watch?v=uhkBJS_n7Qc
Press contact: leo@levelsandbosses.com

## Description

Camoflux is a hand-painted, ecological stealth-exploration game made across Miami and Cali, Colombia, by the independent studio Levels & Bosses. Its worlds are painted as oil paintings and ink drawings and turned into height maps, materials, and dynamic textures; organic models sculpted in VR become sentient, animated actors. One level is built from the Amazonian canvases of María Thereza Negreiros, a painter from Maués in the Brazilian Amazon.
It plays through reciprocity rather than combat. The First-Boss is the entire Level One environment: however gently or violently you approach it, it answers in kind, and rushing to attack is the fastest way to lose. Slow down and observe. Camouflage into hand-painted patterns, modulate turbulence through touch, shift light, and move energy through landscape puzzles.
Camoflux was exhibited as a playable installation at the 2026 Whitney Biennial and is available to wishlist on Steam.

## Studio

Levels & Bosses is the studio of Leo Castañeda (b. 1988, Cali, Colombia), a multimedia artist and video game designer exploring Latin American Surrealism in the digital age. His work takes the form of episodic games and immersive installations that meld atmospheric paintings, video, mixed reality, wearables, and sculpture.
In 2026 Camoflux: Levels & Bosses, Incendio Igapó was exhibited in the Whitney Biennial, and Camoflux Recall Grotto, commissioned for the Whitney's artport, entered the museum's permanent collection. Castañeda is a Knight Foundation Arts + Technology Fellow, YoungArts Artist Technology Fellow, Emergent Strategy Ideation Institute Praxis Project Fellow, Ellies Creator Award recipient, and Harpo Foundation grantee.
He has exhibited at the Whitney Museum of American Art, Pérez Art Museum Miami, the Bronx Museum of the Arts, Haus der elektronischen Künste Basel, Museu do Amanhã in Rio de Janeiro, Espacio ArtNexus Bogotá, Locust Projects Miami, and Museo de Arte Moderno La Tertulia in Colombia. He holds a BFA from Cooper Union and an MFA from Hunter College. Camoflux is published by Otro Inventario.

## Image captions

mangrove-alcove.jpg: Mangrove Alcove, in-game
mangrove-entity.jpg: Mangrove biome: Embedded Entity
mangrove-village.jpg: Mangrove Village: teleporter facing Level One, 2024
igapo-butterfly-drone.jpg: Amazonian Igapó: Butterfly Drone encounter. In collaboration with María Thereza Negreiros, 2025
paramo.jpg: Páramo, in-game
first-boss-render.jpg: Level One: the First-Boss
igapo-roots.jpg: Incendio-Igapó, 2026
lily-pad-hangout.jpg: Incendio-Igapó: lily pad camo hangout, three-channel
walking-panorama.jpg: Walking panorama, 2023
cave-roots.jpg: The porous cave
cave-figures.jpg: The porous cave, with hooded figures
maloca-pause-menu.jpg: Maloca pause menu, concept
level-one-bw.jpg: Level One
level-one.jpg: Level One, trailer capture, 2024